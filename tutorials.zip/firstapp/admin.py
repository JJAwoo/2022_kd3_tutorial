from django.contrib import admin
from firstapp.models import Curriculum
# Register your models here.
admin.site.register(Curriculum)